
package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.EmployeeModel;


/**
 *
 * @author willy
 */
public class EmployeeDao {
    
    String url="jdbc:mysql://localhost:3306/warehouse_db";
    String user="root";
    String password="mysql";
    
    public List<EmployeeModel> retrieveEmp(){
        List<EmployeeModel> emp=new ArrayList<>();
    try{
        Connection con=DriverManager.getConnection(url,user,password);
        CallableStatement cst=con.prepareCall("{call allEmployee()}");
        cst.execute();
        ResultSet rs=cst.getResultSet();
        while(rs.next()){
            EmployeeModel model=new EmployeeModel();
            model.setEmpId(rs.getInt(1));
            model.setEmpNames(rs.getString(2));
            model.setEmpPhone(rs.getString(3));
            model.setEmpMail(rs.getString(4));
            model.setEmpTitle(rs.getString(6));
            model.setCreateDate(rs.getDate(7));
            emp.add(model);
        }
    }catch (Exception ex){
        ex.printStackTrace();
    }
    return emp;
}
                public int checkUser(EmployeeModel mod){
                   int rowsAffected = 0;
                try{
                    Connection con = DriverManager.getConnection(url, user, password);
                    CallableStatement cst = con.prepareCall("{call checkUser(?,?)}");
                    cst.setString(1, mod.getEmpMail());
                    cst.setString(2, mod.getEmpPassword());
                    rowsAffected = cst.executeUpdate();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                return rowsAffected;
                }
    
    public int checkUserAdmin(EmployeeModel mod){
       int rowsAffected = 0;
    try{
        Connection con = DriverManager.getConnection(url, user, password);
        CallableStatement cst = con.prepareCall("{call checkUserAdmin(?,?)}");
        cst.setString(1, mod.getEmpMail());
        cst.setString(2, mod.getEmpPassword());
        rowsAffected = cst.executeUpdate();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return rowsAffected;
    }
    
    //delete
                public int deleteUser(EmployeeModel mod){
                   int rowsAffected = 0;
                try{
                    Connection con = DriverManager.getConnection(url, user, password);
                    CallableStatement cst = con.prepareCall("{call deleteUser(?)}");
                    cst.setInt(1,mod.getEmpId());
                    rowsAffected = cst.executeUpdate();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                return rowsAffected;
                }
    
    //update
    public int updateUser(EmployeeModel mod) {
    int rowsAffected = 0;
    try {
        Connection con = DriverManager.getConnection(url, user, password);
        CallableStatement cst = con.prepareCall("{call updateUser(?,?,?,?)}");
        cst.setInt(1, mod.getEmpId());
        cst.setString(2,mod.getEmpNames());
         cst.setString(3,mod.getEmpPhone());
          cst.setString(4,mod.getEmpMail());
        rowsAffected = cst.executeUpdate();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return rowsAffected;
    }
    
     //update
    public int registerUser(EmployeeModel mod) {
    int rowsAffected = 0;
    try {
        Connection con = DriverManager.getConnection(url, user, password);
        CallableStatement cst = con.prepareCall("{call registerUser(?,?,?,?,?)}");
        cst.setString(1,mod.getEmpNames());
         cst.setString(2,mod.getEmpPhone());
          cst.setString(3,mod.getEmpMail());
          cst.setString(4,mod.getEmpTitle());
          cst.setString(5,mod.getEmpPassword());
        rowsAffected = cst.executeUpdate();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return rowsAffected;
    }
      
//update
  public int makeAdmin(EmployeeModel mod) {
    int rowsAffected = 0;
    try {
        Connection con = DriverManager.getConnection(url, user, password);
        CallableStatement cst = con.prepareCall("{call makeAdmin(?)}");
        cst.setInt(1, mod.getEmpId());
        rowsAffected = cst.executeUpdate();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return rowsAffected;
}
  
}