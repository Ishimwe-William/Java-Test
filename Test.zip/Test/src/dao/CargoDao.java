/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.CargoModel;

/**
 *
 * @author willy
 */
public class CargoDao {
    
    String url="jdbc:mysql://localhost:3306/warehouse_db";
    String user="root";
    String password="mysql";
    
    // call allCargo();
    public List<CargoModel> retrieveCar(){
    List<CargoModel> emp = new ArrayList<>();
    try{
        Connection con = DriverManager.getConnection(url, user, password);
        CallableStatement cst = con.prepareCall("{call allCargo()}");
        cst.execute();
        ResultSet rs = cst.getResultSet();
        while (rs.next()){
            CargoModel model = new CargoModel();
            model.setCargoId(rs.getInt("cargo_id"));
            model.setCargoDescription(rs.getString("Cargo_description"));
            model.setCargoWeight(rs.getDouble("Cargo_Weight"));
            model.setCargoVolume(rs.getDouble("cargo_volume"));
            model.setCargoOrgin(rs.getString("cargo_orgin"));
            model.setCargoDestination(rs.getString("cargo_destination"));
            model.setCargoStatus(rs.getString("cargo_status"));
            model.setCargoOwner(rs.getString("Cargo_owner"));
            model.setCreateDate(rs.getDate("create_date"));
            model.setUpdateDate(rs.getDate("last_updated"));
            emp.add(model);
        }
    } catch (Exception ex){
        ex.printStackTrace();
    }
    return emp;
}

    
    public List<CargoModel> searchCargo(CargoModel owner){
    List<CargoModel> emp=new ArrayList<>();
        try{
          Connection con=DriverManager.getConnection(url,user,password);
            CallableStatement cst=con.prepareCall("{call searchCargo(?)}");
            cst.setString(1, owner.getCargoOwner());
            cst.execute();
            ResultSet rs=cst.getResultSet();
             
            while (rs.next()) {
             CargoModel model=new CargoModel();
             model.setCargoId(rs.getInt("cargo_id"));
             model.setCargoDescription(rs.getString("Cargo_description"));
             model.setCargoWeight(rs.getDouble("Cargo_Weight"));
             model.setCargoVolume(rs.getDouble("cargo_volume"));
             model.setCargoOrgin(rs.getString("cargo_orgin"));
             model.setCargoDestination(rs.getString("cargo_destination"));
             model.setCargoStatus(rs.getString("cargo_status"));
             model.setCargoOwner(rs.getString("Cargo_owner"));
             model.setCreateDate(rs.getDate("create_date"));
             model.setUpdateDate(rs.getDate("last_updated"));
             emp.add(model);
         }
        }catch (Exception ex){
        ex.printStackTrace();
        }
        return emp;
    }
    //delete
     public int deleteCargo(CargoModel mod){
            int rowsAffected = 0;
             try{
                    Connection con = DriverManager.getConnection(url, user, password);
                    CallableStatement cst = con.prepareCall("{call deleteCargo(?)}");
                    cst.setInt(1,mod.getCargoId());
                    rowsAffected = cst.executeUpdate();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
             return rowsAffected;
     }
     //update
    public int updateCargo(CargoModel mod) {
    int rowsAffected = 0;
    try {
        Connection con = DriverManager.getConnection(url, user, password);
        CallableStatement cst = con.prepareCall("{call updateCargo(?,?,?,?,?,?,?)}");
        cst.setInt(1, mod.getCargoId());
        cst.setString(2,mod.getCargoDescription());
        cst.setDouble(3, mod.getCargoWeight());
        cst.setDouble(4, mod.getCargoVolume());
         cst.setString(6,mod.getCargoDestination());
          cst.setString(5,mod.getCargoOrgin());
          cst.setString(7, mod.getCargoStatus());
        rowsAffected = cst.executeUpdate();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return rowsAffected;
    }
    
    public int CheckCargo(CargoModel mod) {
    int rowsAffected = 0;
    try {
        Connection con = DriverManager.getConnection(url, user, password);
        CallableStatement cst = con.prepareCall("{call checkCargo(?,?)}");
        cst.setInt(1, mod.getCargoId());
          cst.setString(2, mod.getCargoStatus());
        rowsAffected = cst.executeUpdate();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return rowsAffected;
    }
    
    //print cargo
    public CargoModel printCargo(int cargoId) {
    CargoModel emp = null;
    try{
        Connection con = DriverManager.getConnection(url, user, password);
        CallableStatement cst = con.prepareCall("{call printCargo(?)}");
        cst.setInt(1, cargoId);
        cst.execute();
        ResultSet rs = cst.getResultSet();
        while (rs.next()){
            CargoModel model = new CargoModel();
            model.setCargoId(rs.getInt("cargo_id"));
            model.setCargoDescription(rs.getString("Cargo_description"));
            model.setCargoWeight(rs.getDouble("Cargo_Weight"));
            model.setCargoVolume(rs.getDouble("cargo_volume"));
            model.setCargoOrgin(rs.getString("cargo_orgin"));
            model.setCargoDestination(rs.getString("cargo_destination"));
            model.setCargoStatus(rs.getString("cargo_status"));
            model.setCargoOwner(rs.getString("Cargo_owner"));
            model.setCreateDate(rs.getDate("create_date"));
            model.setUpdateDate(rs.getDate("last_updated"));
            //emp.add(model);
            emp=model;
        }
    } catch (Exception ex){
        ex.printStackTrace();
    }
    return emp;
}
    //register
    public int registerCargo(CargoModel mod) {
    int rowsAffected = 0;
    try {
        Connection con = DriverManager.getConnection(url, user, password);
        CallableStatement cst = con.prepareCall("{call registerCargo(?,?,?,?,?,?,?)}");
        cst.setString(1,mod.getCargoDescription());
        cst.setDouble(2, mod.getCargoWeight());
        cst.setDouble(3, mod.getCargoVolume());
        cst.setString(4,mod.getCargoOrgin());
         cst.setString(5,mod.getCargoDestination());
          cst.setString(6, mod.getCargoStatus());
          cst.setString(7,mod.getCargoOwner());
        rowsAffected = cst.executeUpdate();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return rowsAffected;
    }
    
}
