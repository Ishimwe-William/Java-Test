package view;

import dao.EmployeeDao;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.EmployeeModel;

/**
 *
 * @author willy
 */
public class Adminstration extends javax.swing.JFrame {
    DefaultTableModel model=new DefaultTableModel();
    /**
     * Creates new form Administration
     */
    public Adminstration() {
        initComponents();
        addColumn();
        addRows();
        idTxt.hide();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        logoutBtn = new javax.swing.JButton();
        homeBtn = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        phoneTxt = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        dataTb = new javax.swing.JTable();
        namesTxt = new javax.swing.JTextField();
        makeAdminBtn = new javax.swing.JButton();
        newEmpBtn = new javax.swing.JButton();
        deleteEmpBtn = new javax.swing.JButton();
        updateEmpbtn = new javax.swing.JButton();
        emailTxt = new javax.swing.JTextField();
        idTxt = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("sansserif", 1, 24)); // NOI18N
        jLabel1.setText("Manage Employee");

        logoutBtn.setText("Logout");
        logoutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutBtnActionPerformed(evt);
            }
        });

        homeBtn.setText("Back Home");
        homeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeBtnActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        dataTb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        dataTb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dataTbMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(dataTb);

        makeAdminBtn.setText("Make an Admin");
        makeAdminBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                makeAdminBtnActionPerformed(evt);
            }
        });

        newEmpBtn.setText("Add new");
        newEmpBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newEmpBtnActionPerformed(evt);
            }
        });

        deleteEmpBtn.setText("Delete");
        deleteEmpBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteEmpBtnActionPerformed(evt);
            }
        });

        updateEmpbtn.setText("Update");
        updateEmpbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateEmpbtnActionPerformed(evt);
            }
        });

        idTxt.setEditable(false);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 563, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(phoneTxt)
                            .addComponent(namesTxt)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(deleteEmpBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(updateEmpbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(20, 20, 20))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(makeAdminBtn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(newEmpBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(emailTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(idTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(idTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(phoneTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(emailTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(namesTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(deleteEmpBtn)
                            .addComponent(updateEmpbtn))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(makeAdminBtn)
                            .addComponent(newEmpBtn))
                        .addGap(42, 42, 42))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(homeBtn)
                .addGap(628, 628, 628)
                .addComponent(logoutBtn)
                .addContainerGap(37, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(298, 298, 298))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(logoutBtn)
                    .addComponent(homeBtn))
                .addGap(23, 23, 23))
        );

        setSize(new java.awt.Dimension(867, 529));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void updateEmpbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateEmpbtnActionPerformed
        if(idTxt.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"No employee selected");
        }else{
            if(namesTxt.getText().trim().isEmpty() || phoneTxt.getText().trim().isEmpty() || emailTxt.getText().trim().isEmpty()){
                JOptionPane.showMessageDialog(this,"All field are required");
            }else{
                EmployeeModel md=new EmployeeModel();
                md.setEmpId(Integer.parseInt(idTxt.getText()));
                md.setEmpNames(namesTxt.getText());
                md.setEmpPhone(phoneTxt.getText());
                md.setEmpMail(emailTxt.getText().toLowerCase());
                EmployeeDao dao=new EmployeeDao();
                if(dao.updateUser(md)!=0){
                    JOptionPane.showMessageDialog(this,"Employee updated!");
                    addRows();
                }
                else{
                    JOptionPane.showMessageDialog(this,"Employee not updated!");
                } }
        }
    }//GEN-LAST:event_updateEmpbtnActionPerformed

    private void addColumn(){
        model.addColumn("ID");
        model.addColumn("Names");
        model.addColumn("Phone");
        model.addColumn("Email");
        model.addColumn("Title");
        model.addColumn("Created");
        dataTb.setModel(model);
    }
    
    private void addRows(){
        model.setRowCount(0);
        EmployeeDao dao=new EmployeeDao();
        List<EmployeeModel> emp=dao.retrieveEmp();
        for(EmployeeModel empM:emp){
            model.addRow(new Object[]{
                empM.getEmpId(),
                empM.getEmpNames(),
                empM.getEmpPhone(),
                empM.getEmpMail(),
                empM.getEmpTitle(),
                empM.getCreateDate()});
        }
    }
    private void deleteEmpBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteEmpBtnActionPerformed
        if(idTxt.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"No employee selected");
        }else{
            if(JOptionPane.showConfirmDialog(this,"Are you sure?","WARNING",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
                EmployeeModel md=new EmployeeModel();
                md.setEmpId(Integer.parseInt(idTxt.getText()));
                EmployeeDao dao=new EmployeeDao();
                if(dao.deleteUser(md)!=0){
                    JOptionPane.showMessageDialog(this,"Employee deleted!");
                    addRows();
                }
                else{
                    JOptionPane.showMessageDialog(this,"Employee not deleted!");
                }
            }
        }
    }//GEN-LAST:event_deleteEmpBtnActionPerformed

    private void homeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeBtnActionPerformed
        dispose();
        Home hm=new Home();
        hm.setVisible(true);
    }//GEN-LAST:event_homeBtnActionPerformed

    private void logoutBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutBtnActionPerformed
        dispose();
        Dashboard dash=new Dashboard();
        dash.setVisible(true);
    }//GEN-LAST:event_logoutBtnActionPerformed

    private void dataTbMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dataTbMouseClicked
        String name=model.getValueAt(dataTb.getSelectedRow(),1).toString();
        String phone=model.getValueAt(dataTb.getSelectedRow(),2).toString();
        String email=model.getValueAt(dataTb.getSelectedRow(),3).toString();
        String id=model.getValueAt(dataTb.getSelectedRow(),0).toString();
        namesTxt.setText(name);
        phoneTxt.setText(phone);
        emailTxt.setText(email);
        idTxt.setText(id);
    }//GEN-LAST:event_dataTbMouseClicked

    private void makeAdminBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_makeAdminBtnActionPerformed
        if(idTxt.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"No employee selected");
        }else{
            if(JOptionPane.showConfirmDialog(this,"Are you sure?","WARNING",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
                EmployeeModel md=new EmployeeModel();
                md.setEmpId(Integer.parseInt(idTxt.getText()));
                EmployeeDao dao=new EmployeeDao();
                if(dao.makeAdmin(md)!=0){
                    JOptionPane.showMessageDialog(this,"Employee now Admin!");
                    addRows();
                }
                else{
                    JOptionPane.showMessageDialog(this,"Employee not updated!");
                }
            }
        }
    }//GEN-LAST:event_makeAdminBtnActionPerformed

    private void newEmpBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newEmpBtnActionPerformed
        Register rg=new Register();
        rg.setVisible(true);
    }//GEN-LAST:event_newEmpBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Adminstration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Adminstration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Adminstration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Adminstration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Adminstration().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable dataTb;
    private javax.swing.JButton deleteEmpBtn;
    private javax.swing.JTextField emailTxt;
    private javax.swing.JButton homeBtn;
    private javax.swing.JTextField idTxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logoutBtn;
    private javax.swing.JButton makeAdminBtn;
    private javax.swing.JTextField namesTxt;
    private javax.swing.JButton newEmpBtn;
    private javax.swing.JTextField phoneTxt;
    private javax.swing.JButton updateEmpbtn;
    // End of variables declaration//GEN-END:variables
}
