/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

/**
 *
 * @author willy
 */
public class CargoModel {
    private int cargoId;
    private String cargoDescription;
    private Double cargoWeight;
    private Double cargoVolume;
    private String cargoDestination;
    private String cargoOrgin;
    private String cargoStatus;
    private String cargoOwner;
    private Date createDate;
    private Date updateDate;

    public CargoModel() {
    }

    public CargoModel(int cargoId, String cargoDescription, Double cargoWeight, Double cargoVolume, String cargoDestination, String cargoOrgin, String cargoStatus, String cargoOwner, Date createDate, Date updateDate) {
        this.cargoId = cargoId;
        this.cargoDescription = cargoDescription;
        this.cargoWeight = cargoWeight;
        this.cargoVolume = cargoVolume;
        this.cargoDestination = cargoDestination;
        this.cargoOrgin = cargoOrgin;
        this.cargoStatus = cargoStatus;
        this.cargoOwner = cargoOwner;
        this.createDate = createDate;
        this.updateDate = updateDate;
    }

    public String getCargoOrgin() {
        return cargoOrgin;
    }

    public void setCargoOrgin(String cargoOrgin) {
        this.cargoOrgin = cargoOrgin;
    }

   

    public int getCargoId() {
        return cargoId;
    }

    public void setCargoId(int cargoId) {
        this.cargoId = cargoId;
    }

    public String getCargoDescription() {
        return cargoDescription;
    }

    public void setCargoDescription(String cargoDescription) {
        this.cargoDescription = cargoDescription;
    }

    public Double getCargoWeight() {
        return cargoWeight;
    }

    public void setCargoWeight(Double cargoWeight) {
        this.cargoWeight = cargoWeight;
    }

    public Double getCargoVolume() {
        return cargoVolume;
    }

    public void setCargoVolume(Double cargoVolume) {
        this.cargoVolume = cargoVolume;
    }

    public String getCargoDestination() {
        return cargoDestination;
    }

    public void setCargoDestination(String cargoDestination) {
        this.cargoDestination = cargoDestination;
    }

    public String getCargoStatus() {
        return cargoStatus;
    }

    public void setCargoStatus(String cargoStatus) {
        this.cargoStatus = cargoStatus;
    }

    public String getCargoOwner() {
        return cargoOwner;
    }

    public void setCargoOwner(String cargoOwner) {
        this.cargoOwner = cargoOwner;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
    
}
