/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

/**
 *
 * @author willy
 */
public class EmployeeModel {
    private int empId;
    private String empNames;
    private String empPhone;
    private String empMail;
    private String empPassword;
    private String empTitle;
    private Date createDate;

    public EmployeeModel() {
    }

    public EmployeeModel(int empId, String empNames, String empPhone, String empMail, String empPassword, String empTitle, Date createDate) {
        this.empId = empId;
        this.empNames = empNames;
        this.empPhone = empPhone;
        this.empMail = empMail;
        this.empPassword = empPassword;
        this.empTitle = empTitle;
        this.createDate = createDate;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpNames() {
        return empNames;
    }

    public void setEmpNames(String empNames) {
        this.empNames = empNames;
    }

    public String getEmpPhone() {
        return empPhone;
    }

    public void setEmpPhone(String empPhone) {
        this.empPhone = empPhone;
    }

    public String getEmpMail() {
        return empMail;
    }

    public void setEmpMail(String empMail) {
        this.empMail = empMail;
    }

    public String getEmpPassword() {
        return empPassword;
    }

    public void setEmpPassword(String empPassword) {
        this.empPassword = empPassword;
    }

    public String getEmpTitle() {
        return empTitle;
    }

    public void setEmpTitle(String empTitle) {
        this.empTitle = empTitle;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }    
}
